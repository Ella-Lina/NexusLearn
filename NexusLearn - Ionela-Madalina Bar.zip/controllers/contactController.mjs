import { dbService } from "../dbService.mjs";

function get(req, res) {
  res.render("contact", { title: "Contact Us" });
}

function post(req, res) {
  const { name, email, message } = req.body;

  if (!name || !email || !message) {
    return res.status(400).send("All fields are required.");
  }

  dbService.saveContactMessage(name, email, message, (err) => {
    if (err) {
      console.error("Error saving message:", err);
      return res.status(500).send("Error saving message.");
    }

    res.redirect("/contact-success");
  });
}

export default {
  get,
  post,
};
